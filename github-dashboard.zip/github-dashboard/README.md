# Garrett's GitHub Project Dashboard

A static, dark-themed dashboard for GitHub user `garrettkleinhen8-glitch`.

## Features
- Live public repository list, search, sorting, stars, forks, and last-update dates
- Public repository count and open issue counts (GitHub's `open_issues_count` includes pull requests)
- Recent public GitHub events
- Personal tasks with priority, repository association, and progress tracking
- Responsive design for desktop and mobile

## Publish with GitHub Pages
1. Create a new **public** GitHub repository, e.g. `github-dashboard`.
2. Upload `index.html` to the repository root and commit it.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Open `https://garrettkleinhen8-glitch.github.io/github-dashboard/` once Pages has deployed.

Alternatively, open `index.html` locally in a browser. Some browsers may block requests from local files; using a local HTTP server is more reliable (`python -m http.server 8000`).

## Data and privacy
- The dashboard uses GitHub's unauthenticated REST API, so it only displays **public** GitHub data. GitHub's unauthenticated rate limit is typically 60 requests/hour per IP.
- Task data is saved in the browser's `localStorage`. Tasks are **not** synced between devices, uploaded to GitHub, or backed up. Clearing site data removes them.
- GitHub's `open_issues_count` can include pull requests and should be interpreted accordingly.
- Repository listing is capped at 1,000 public repositories in this lightweight build.
- No token is stored in source code. Do not put a private GitHub token into a public Pages site.

## Customize
Edit the `USER` constant in the JavaScript near the end of `index.html` to point at another GitHub account. Update the profile links and branding as desired.
